package com.rntbci.bleclient;

import android.annotation.TargetApi;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.ParcelUuid;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.jar.Manifest;


@TargetApi(Build.VERSION_CODES.LOLLIPOP)
public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener ,View.OnClickListener {
    private BluetoothAdapter mBluetoothAdapter;
    private int REQUEST_ENABLE_BT = 1;
    private Handler mHandler;
    private static final long SCAN_PERIOD = 10000;
    private BluetoothLeScanner mLEScanner;
    private ScanSettings settings;
    private List<ScanFilter> filters;
    private BluetoothGatt mGatt;
    private String TAG="BLECLIENT";
    private ArrayList<BluetoothDevice> btdevicelist;
    BluetoothDevice btdevice;
    private ListView transmitdata;
    ArrayList<String> incomedata;
    ArrayAdapter<String> transmitdataadp;
    TextView conectionstat;
    EditText edittxt;
    Button sendbutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar_content);

        //android.Manifest.permission.ACCESS_FINE_LOCATION
        if(Build.VERSION.SDK_INT >= 23 && ContextCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_DENIED)
        {
            ActivityCompat.requestPermissions(this,new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},1000);
        }






        setContentView(R.layout.activity_main);
        mHandler = new Handler();

        transmitdata=(ListView)findViewById(R.id.transmitdata) ;

        incomedata=new ArrayList<String>();
        transmitdataadp=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,incomedata);
        transmitdata.setAdapter(transmitdataadp);
   //     devicelist.setOnItemClickListener(this);




        conectionstat=(TextView) findViewById(R.id.conectionstat);
        edittxt=(EditText)findViewById(R.id.edittxt);
        sendbutton=(Button)findViewById(R.id.sendbutton);

        sendbutton.setOnClickListener(this);

        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, "BLE Not Supported",
                    Toast.LENGTH_SHORT).show();
            finish();
        }
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();


    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        } else {
            if (Build.VERSION.SDK_INT >= 21) {
                mLEScanner = mBluetoothAdapter.getBluetoothLeScanner();
                settings = new ScanSettings.Builder()
                        .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                        .build();
                filters = new ArrayList<ScanFilter>();
                ScanFilter.Builder builder=new ScanFilter.Builder();
                filters.add(builder.setServiceUuid(ParcelUuid.fromString("1706BBC0-88AB-4B8D-877E-2237916EE929")).build());
            }
            btdevicelist=new ArrayList<BluetoothDevice>();
          //  deviceListAdapter=new DeviceListAdapter(this,btdevicelist);
        //    devicelist.setAdapter(deviceListAdapter);
            scanLeDevice(true);
        }
    }


    @Override
    protected void onPause() {
        super.onPause();
        if (mBluetoothAdapter != null && mBluetoothAdapter.isEnabled()) {
            scanLeDevice(false);
        }
    }

    @Override
    protected void onStop() {

        if (mGatt != null) {
            mGatt.close();
            mGatt = null;
        }


        super.onStop();

    }

    @Override
    protected void onDestroy() {

        super.onDestroy();
    }


    private ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            Log.i("callbackType", String.valueOf(callbackType));
            Log.i("result", result.toString());
            BluetoothDevice btDevice = result.getDevice();
            btdevice=btDevice;
            connectToDevice(btDevice);


           /* if(!btdevicelist.contains(btDevice)) {
                btdevicelist.add(btDevice);
                deviceListAdapter.notifyDataSetChanged();
            }*/


        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            for (ScanResult sr : results) {
                Log.i("ScanResult - Results", sr.toString());
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            Log.e("Scan Failed", "Error Code: " + errorCode);
        }
    };


    private void scanLeDevice(final boolean enable) {

        if (enable) {
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT < 21) {
                        mBluetoothAdapter.stopLeScan(mLeScanCallback);
                    } else {
                        mLEScanner.stopScan(mScanCallback);

                    }
                }
            }, SCAN_PERIOD);
            if (Build.VERSION.SDK_INT < 21) {
                mBluetoothAdapter.startLeScan(mLeScanCallback);
            } else {


                mLEScanner.startScan(filters, settings, mScanCallback);
            }
        } else {
            if (Build.VERSION.SDK_INT < 21) {
                mBluetoothAdapter.stopLeScan(mLeScanCallback);
            } else {
                mLEScanner.stopScan(mScanCallback);
            }
        }
    }


    private BluetoothAdapter.LeScanCallback mLeScanCallback =
            new BluetoothAdapter.LeScanCallback() {
                @Override
                public void onLeScan(final BluetoothDevice device, int rssi,
                                     byte[] scanRecord) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.i(TAG, device.toString());
                            //connectToDevice(device);
                        }
                    });
                }
            };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == Activity.RESULT_CANCELED) {
                //Bluetooth not enabled.
                finish();
                return;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }


    public void connectToDevice(BluetoothDevice device) {
        if (mGatt == null) {
            mGatt = device.connectGatt(this, false, gattCallback);


            scanLeDevice(false);// will stop after first device detection
        }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            Log.i(TAG, "Status: " + status);
            switch (newState) {
                case BluetoothProfile.STATE_CONNECTED:
                    Log.i(TAG, "STATE_CONNECTED");

                    postStatusMessage("Connected");
                    gatt.discoverServices();
                    break;
                case BluetoothProfile.STATE_DISCONNECTED:
                    Log.e(TAG, "STATE_DISCONNECTED");
                    postStatusMessage("Disconnected");
                    break;
                default:
                    Log.e(TAG, "STATE_OTHER");
                    postStatusMessage("-");
                    break;
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            List<BluetoothGattService> services = gatt.getServices();
            Log.i(TAG+"Discovered", services.toString());

            setnotification();



        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            String str = new String(characteristic.getValue(), StandardCharsets.UTF_8);


            Log.i(TAG, "onCharacteristicRead"+str);
        //    gatt.disconnect();


        }

        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            super.onMtuChanged(gatt, mtu, status);
            Log.i(TAG, "onMtuChanged");
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {

            String str = new String(characteristic.getValue(), StandardCharsets.UTF_8);

            Log.i(TAG, "onCharacteristicWrite :"+str);

        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {

            String str = new String(characteristic.getValue(), StandardCharsets.UTF_8);

            incomedata.add(str);

            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    transmitdataadp.notifyDataSetChanged();
                }
            });

            Log.i(TAG, "onCharacteristicChanged : "+str);

        }

        @Override
        public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            Log.i(TAG, "onDescriptorRead");
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            Log.i(TAG, "onDescriptorWrite");
        }

        @Override
        public void onReliableWriteCompleted(BluetoothGatt gatt, int status) {
            Log.i(TAG, "onReliableWriteCompleted");
        }

        @Override
        public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
            Log.i(TAG, "onReadRemoteRssi");
        }
    };

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        connectToDevice(btdevicelist.get(position));

    }


    private Handler mHandler1 = new Handler();
    private void postStatusMessage(final String message) {
        mHandler1.post(new Runnable() {
            @Override
            public void run() {
//                setTitle(message);
                conectionstat.setText(message);
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.sendbutton:
//                mGatt.requestMtu(512);
                if(!edittxt.getText().toString().equals("")) {
                    send(edittxt.getText().toString().getBytes());
                    edittxt.setText("");
                }
                break;
        }
    }




    public boolean setnotification() {
        if (mGatt == null || mGatt == null) {
            Log.w(TAG, "BluetoothGatt not initialized");
            return false;
        }

        BluetoothGattService bluetoothGattService=mGatt.getService(UUID.fromString("1706BBC0-88AB-4B8D-877E-2237916EE929"));

        if (bluetoothGattService==null)
        {
            Log.w(TAG, "BluetoothGatt service not found");
            return false;
        }

        BluetoothGattCharacteristic characteristic =
                bluetoothGattService.getCharacteristic(UUID.fromString("BD28E457-4026-4270-A99F-F9BC20182E15"));

        if (characteristic == null) {
            Log.w(TAG, "Send characteristic not found");
            return false;
        }
        Log.w(TAG, "set notify success");
        return mGatt.setCharacteristicNotification(characteristic,true);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode==1000){
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                scanLeDevice(true);
            }
            else
            {
                scanLeDevice(false);
                finish();
            }
        }
    }

    public boolean send(byte[] data) {
        if (mGatt == null || mGatt == null) {
            Log.w(TAG, "BluetoothGatt not initialized");
            return false;
        }

        BluetoothGattService bluetoothGattService=mGatt.getService(UUID.fromString("1706BBC0-88AB-4B8D-877E-2237916EE929"));
        if (bluetoothGattService==null)
        {
            Log.w(TAG, "BluetoothGatt service not found");
            return false;
        }
        BluetoothGattCharacteristic characteristic =
                bluetoothGattService.getCharacteristic(UUID.fromString("BD28E457-4026-4270-A99F-F9BC20182E15"));

        if (characteristic == null) {
            Log.w(TAG, "Send characteristic not found");
            return false;
        }

        characteristic.setValue(data);
        characteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
        return mGatt.writeCharacteristic(characteristic);

    }
}
