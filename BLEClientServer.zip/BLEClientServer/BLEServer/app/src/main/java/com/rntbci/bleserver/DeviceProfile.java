package com.rntbci.bleserver;

import java.util.UUID;

/**
 * Created by z020115 on 07-03-2017.
 */

public class DeviceProfile {
    /* Unique ids generated for this device by 'uuidgen'. Doesn't conform to any SIG profile. */

    //Service UUID to expose our time characteristics
    public static UUID SERVICE_UUID = UUID.fromString("1706BBC0-88AB-4B8D-877E-2237916EE929");
    //Read-only characteristic providing number of elapsed seconds since offset
    public static UUID CHARACTERISTIC_ELAPSED_UUID = UUID.fromString("275348FB-C14D-4FD5-B434-7C3F351DEA5F");
    //Read-write characteristic for current offset timestamp
    public static UUID CHARACTERISTIC_OFFSET_UUID = UUID.fromString("BD28E457-4026-4270-A99F-F9BC20182E15");


}
